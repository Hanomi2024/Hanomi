(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/contentScript.ts-f5c622c8.js")
    );
  })().catch(console.error);

})();
