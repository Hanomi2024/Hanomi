import"./modulepreload-polyfill-3cfb730f.js";import{F as o,a as r,b as n}from"./Fuel-752e7d2f.js";import"./index-4fbb3b05.js";import{A as t}from"./configs-166b2f08.js";window.fuel=new o({connectors:[new r,new n]});window.createAddress=e=>t.fromString(e);
//# sourceMappingURL=e2e-d20a1ffd.js.map
